ReadMe

To compile the program:
	javac Assign4.java DiGraph.java Edge.java LList.java Matrix2D.java Queue.java Vertex.java WeightedEdge.java
To run the program
	java Assign4 input.txt query.txt output1.txt output2.txt inputDijkstra1.txt queryDijkstra1.txt output3.txt
	
Note: I attempted the bonus section of this assignment